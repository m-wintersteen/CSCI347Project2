import csv

with open('heart.dat.csv') as csv_file:
    csv_reader = csv.reader(csv_file, ' ')
    line = 0
    for row in csv_reader:
        print (', '.join(row))

        line += 1


print("here")
